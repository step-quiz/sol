/* ═══════════════════════════════════════════════════════════════════════
   LES ERRADES DEL SOLUCIONARI
   ───────────────────────────────────────────────────────────────────────
   El solucionari té errades. Aquí hi ha les dels exercicis programats a
   tasques.js. La clau és la mateixa que a hints.js:  'unitat/exercici'.

     'u7/76': [
       { lloc:    TEX`f)`,
         ondiu:   TEX`$\dlim_{x\to 3}\dfrac{3-x}{x+2}=0$`,
         hadedir: TEX`$\dlim_{x\to 3}\dfrac{-(3+x)}{x+2}=-\dfrac{6}{5}$`,
         motiu:   TEX`Els factors $3-x$ i $x-3$ són oposats.` },
     ],

   Cada exercici porta una LLISTA d'errades (entre [ ]), en l'ordre en què
   surten a la solució. De cada errada:

     lloc      on és: l'apartat i, si cal, un detall
               (TEX`f)` , TEX`e), punt $x=1$` , TEX`segon punt` ...).
               Si no cal dir res, aquesta línia no es posa.
     ondiu     el que hi ha imprès al solucionari
     hadedir   el que hi hauria de dir
     motiu     l'explicació. Només es veu si ERRADES_MOTIU és true.
     enunciat  s'escriu  enunciat: 1  quan l'errada és a l'ENUNCIAT i no a la
               solució. Aquestes es mostren ja a la llista de la tasca,
               abans que l'alumne comenci l'exercici.

   Un exercici sense entrada aquí no mostra res: no cal deixar-hi cap
   llista buida.

   COM S'ESCRIU EL TEXT
     · Sempre entre accents greus i amb TEX al davant:  TEX`...`
       Així el LaTeX s'escriu tal qual, sense doblar cap barra invertida.
     · Les fórmules van entre dòlars, $...$, com en un fitxer .tex.
       Les pinta KaTeX (assets/katex). Hi ha definides \dlim (límit amb el
       subíndex a sota) i \R (els nombres reals), com a defs.tex.
     · Fora dels dòlars és text normal. Només s'hi entenen tres comandes
       d'espai:  \quad   \;   \,
     · Dins del text no hi pot haver cap accent greu ni la parella ${

   ON ES VEU (tasca.html)
     · A la llista de la tasca: una etiqueta vermella al costat del botó
       «Veure solució» («2 errades al solucionari»). Les errades d'enunciat
       hi surten senceres, perquè s'han de saber abans de començar.
     · Dins de l'exercici: una targeta «On diu / Ha de dir» per errada, just
       abans de la imatge.

   Les errades surten del projecte d'Overleaf «Errades del solucionari»
   (errors-setmanaN.tex), convertit un sol cop. A partir d'ara s'editen aquí.
   ═══════════════════════════════════════════════════════════════════════ */

/* ── Interruptors ───────────────────────────────────────────────────────
   Són els dos que hi havia a dalt de main.tex. Per encendre'n un, canvia
   false per true. */
const ERRADES_MOTIU = false;   // true: cada errada mostra també el «Motiu»
const ERRADES_OBS   = false;   // true: es veuen també les observacions

const TEX = String.raw;        // no toquis aquesta línia

const ERRADES = {

  /* ── Unitat 1 · Matrius ──────────────────────────────────────────────── */

  'u1/49': [
    { lloc:    TEX`d)`,
      ondiu:   TEX`$BC=\begin{pmatrix}-7 & 3 & 3\\ -1 & -1 & 8\end{pmatrix}$`,
      hadedir: TEX`$BC=\begin{pmatrix}-8 & 3 & 3\\ -4 & -1 & 8\end{pmatrix}$`,
      motiu:   TEX`Els dos elements de la primera columna estan malament: $(-2)\cdot 4+1\cdot 0+1\cdot 0=-8$ i $(-1)\cdot 4+0\cdot 0+3\cdot 0=-4$.` },
  ],

  /* ── Unitat 2 · Determinants ─────────────────────────────────────────── */

  'u2/80': [
    { lloc:    TEX`b)`,
      ondiu:   TEX`$\begin{vmatrix}3&-5&1\\4&1&-2\\7&-4&-2\end{vmatrix}=0$`,
      hadedir: TEX`$\begin{vmatrix}3&-5&1\\4&1&-2\\7&-4&-1\end{vmatrix}=0$`,
      motiu:   TEX`La fila que s'ha afegit a la matriu és $(7,-4,-1)$, la suma de les altres dues, i per això el determinant és $0$. Amb $-2$ al final, el determinant valdria $-23$.` },
  ],

  'u2/95': [
    { enunciat: 1,
      ondiu:   TEX`III) $-\dfrac{1}{2}\begin{pmatrix}4&-3\\-2&2\end{pmatrix}$`,
      hadedir: TEX`III) $-\dfrac{1}{2}\begin{pmatrix}4&-3\\-2&1\end{pmatrix}$`,
      motiu:   TEX`És una errada de l'enunciat. La inversa de $\begin{pmatrix}1&3\\2&4\end{pmatrix}$ és $\dfrac{1}{-2}\begin{pmatrix}4&-3\\-2&1\end{pmatrix}$: l'últim element és $1$. Tal com està impresa, l'opció III) no és la inversa de cap de les tres matrius; la relació b) $\rightarrow$ III) de la solució és la que es volia.` },
  ],

  /* ── Unitat 3 · Sistemes d'equacions ─────────────────────────────────── */

  'u3/41': [
    { lloc:    TEX`d)`,
      ondiu:   TEX`$2x-z=2$`,
      hadedir: TEX`$2x+z=2$`,
      motiu:   TEX`La segona fila de la matriu és $(2\;\;0\;\;1)$: el coeficient de $z$ és $1$.` },
  ],

  'u3/43': [
    { lloc:    TEX`f)`,
      ondiu:   TEX`$F_3=F_3-2F_1$`,
      hadedir: TEX`$F_3=F_3-2F_2$`,
      motiu:   TEX`L'operació que anul·la la tercera fila, $(0\;\;10\;\;34\mid 2)$, és restar-li el doble de la segona, $(0\;\;5\;\;17\mid 1)$. La matriu que surt a continuació ja és la correcta.` },
  ],

  'u3/55': [
    { lloc:    TEX`d)`,
      ondiu:   TEX`$\begin{vmatrix}1&1\\0&-1\end{vmatrix}=1\neq 0$`,
      hadedir: TEX`$\begin{vmatrix}1&1\\0&1\end{vmatrix}=1\neq 0$`,
      motiu:   TEX`El menor es pren de la matriu $A$, i l'element de la segona fila és $1$. Amb $-1$ el determinant valdria $-1$.` },
  ],

  'u3/56': [
    { lloc:    TEX`d)`,
      ondiu:   TEX`$\begin{vmatrix}3&2&7\\1&-1&6\\6&-1&-3\end{vmatrix}=110\neq 0$`,
      hadedir: TEX`$\begin{vmatrix}3&2&7\\1&-1&6\\6&-1&3\end{vmatrix}=110\neq 0$`,
      motiu:   TEX`L'última columna és la dels termes independents, $7$, $6$ i $3$. Amb $3$ el determinant val $110$; amb $-3$ valdria $140$.` },
  ],

  'u3/60': [
    { lloc:    TEX`a)`,
      ondiu:   TEX`«Si $m\neq 3$, $m\neq -3$ $\rightarrow$ $\mathrm{Rang}(A)=\mathrm{Rang}(A^*)=2<$ nre. d'incògnites $\rightarrow$ Sistema compatible determinat»`,
      hadedir: TEX`«Si $m\neq 3$, $m\neq -3$ $\rightarrow$ $\mathrm{Rang}(A)=\mathrm{Rang}(A^*)=2=$ nre. d'incògnites $\rightarrow$ Sistema compatible determinat»`,
      motiu:   TEX`El sistema té dues incògnites, $x$ i $y$, i el rang és $2$: són iguals, i per això és compatible determinat. Si el rang fos més petit que el nombre d'incògnites, seria indeterminat.` },
    { lloc:    TEX`d)`,
      ondiu:   TEX`«Si $m=-4$ $\rightarrow$ $\mathrm{Rang}(A)=1$ $\rightarrow$ $\mathrm{Rang}(A)\neq\mathrm{Rang}(A)=2$»`,
      hadedir: TEX`«Si $m=-4$ $\rightarrow$ $\mathrm{Rang}(A)=1$ $\rightarrow$ $\mathrm{Rang}(A)\neq\mathrm{Rang}(A^*)=2$»`,
      motiu:   TEX`La que té rang $2$ és la matriu ampliada $A^*$; hi falta l'asterisc.` },
    { lloc:    TEX`f), cas $m=0$`,
      ondiu:   TEX`$\begin{vmatrix}-1&2\\1&2\end{vmatrix}=-6\neq 0$`,
      hadedir: TEX`$\begin{vmatrix}-1&2\\2&2\end{vmatrix}=-6\neq 0$`,
      motiu:   TEX`El menor surt de les files 2 i 3 de $A$ (columnes 1 i 3), que per a $m=0$ són $(-1\;\;0\;\;2)$ i $(2\;\;0\;\;2)$. Amb un $1$ el determinant valdria $-4$. Al cas $m=3$ la solució l'escriu bé.` },
  ],

  'u3/90': [
    { ondiu:   TEX`$F_2=2F_1-F_2$ \; (primera operació)`,
      hadedir: TEX`$F_1=2F_1-F_2$`,
      motiu:   TEX`La fila que canvia és la primera: $2F_1-F_2=(10\;\;10\;\;0\mid 42)$, i les altres dues queden igual.` },
  ],

  'u3/100': [
    { ondiu:   TEX`$A=\begin{pmatrix}0&2&3\\4&0&3\\5&2&1\end{pmatrix}$ \; (i el mateix a la matriu $A^*$)`,
      hadedir: TEX`$A=\begin{pmatrix}0&2&3\\4&0&1\\5&2&0\end{pmatrix}$`,
      motiu:   TEX`Les files són els coeficients de $2p_2+3p_3=440$, $4p_1+p_3=240$ i $5p_1+2p_2=360$. Els determinants de Cramer que venen després ja fan servir la matriu correcta.` },
  ],

  /* ── Unitat 5 · Rectes i plans en l'espai ────────────────────────────── */

  'u5/46': [
    { ondiu:   TEX`$\dfrac{x-1}{1}=\dfrac{y-2}{2}$ \; (equació implícita)`,
      hadedir: TEX`$\dfrac{x-1}{-1}=\dfrac{y-2}{2}$`,
      motiu:   TEX`El denominador és la primera coordenada del vector director, $-1$. Amb $-1$ surt $2x+y-4=0$, que és el resultat de la solució; amb $1$ sortiria $2x-y=0$.` },
  ],

  'u5/49': [
    { lloc:    TEX`a)`,
      ondiu:   TEX`$\dfrac{x=0}{2}=\dfrac{y-3}{5}=\dfrac{z-0}{1}$`,
      hadedir: TEX`$\dfrac{x-0}{2}=\dfrac{y-3}{5}=\dfrac{z-0}{1}$`,
      motiu:   TEX`Al primer numerador hi ha d'haver un signe menys, no un igual.` },
    { lloc:    TEX`b)`,
      ondiu:   TEX`$x-2\lambda$; \; $y=\lambda$; \; $z=\lambda$`,
      hadedir: TEX`$x=2\lambda$; \; $y=\lambda$; \; $z=\lambda$`,
      motiu:   TEX`De $x-2y=0$ amb $y=\lambda$ surt $x=2\lambda$.` },
  ],

  'u5/56': [
    { ondiu:   TEX`$z=\lambda$; \; $y=\lambda$; \; $z=\lambda$`,
      hadedir: TEX`$x=\lambda$; \; $y=\lambda$; \; $z=\lambda$`,
      motiu:   TEX`La primera equació paramètrica és la de $x$.` },
  ],

  'u5/59': [
    { lloc:    TEX`b)`,
      ondiu:   TEX`$-z+6=0 \;\rightarrow\; z=-6 \;\rightarrow\; P_Z(0,0,6)$`,
      hadedir: TEX`$-z+6=0 \;\rightarrow\; z=6 \;\rightarrow\; P_Z(0,0,6)$`,
      motiu:   TEX`De $-z+6=0$ surt $z=6$. El punt $P_Z(0,0,6)$ ja és correcte.` },
  ],

  'u5/63': [
    { ondiu:   TEX`$\dfrac{x-4}{2}=\dfrac{y+2}{4}=\dfrac{z-1}{-2}$`,
      hadedir: TEX`$\dfrac{x-4}{-2}=\dfrac{y+2}{4}=\dfrac{z-1}{-2}$`,
      motiu:   TEX`El vector director és $\overrightarrow{AB}=(-2,4,-2)$. A la línia següent, quan s'hi substitueix el punt $C$, la solució ja hi posa $-2$.` },
  ],

  'u5/77': [
    { lloc:    TEX`b)`,
      ondiu:   TEX`$M^*=\begin{pmatrix}1&-2&-1&-1\\2&1&5&5\\7&-4&7&7\end{pmatrix}$`,
      hadedir: TEX`$M^*=\begin{pmatrix}1&-2&3&-1\\2&1&-1&5\\7&-4&7&7\end{pmatrix}$`,
      motiu:   TEX`La tercera columna és la dels coeficients de $z$ ($3$, $-1$ i $7$); a la solució hi surt repetida la dels termes independents.` },
  ],

  'u5/80': [
    { ondiu:   TEX`«Les rectes són paral·leles quan $m=2$.»`,
      hadedir: TEX`«Les rectes són paral·leles quan $m=-2$.»`,
      motiu:   TEX`És el valor que surt del sistema de la línia anterior. Amb $m=2$ es compleix $m^2=4$, però no $2-m\neq 0$: les dues rectes serien la mateixa. El pla que es calcula després ja fa servir $m=-2$.` },
  ],

  /* ── Unitat 6 · Angles i distàncies a l'espai ────────────────────────── */

  'u6/74': [
    { ondiu:   TEX`«c) Trobem la projecció ortogonal del punt sobre la recta.»`,
      hadedir: TEX`«b) Trobem la projecció ortogonal del punt sobre la recta.»`,
      motiu:   TEX`L'exercici només té dos apartats; aquest és el b), el del punt $P(-1,2,13)$.` },
  ],

  'u6/86': [
    { lloc:    TEX`b)`,
      ondiu:   TEX`$\vec{n}=(2,-2,1)$`,
      hadedir: TEX`$\vec{n}=(2,-2,-1)$`,
      motiu:   TEX`El coeficient de $z$ del pla $2x-2y-z+1=0$ és $-1$. El mòdul, $3$, i la distància, $1$ u, no canvien.` },
  ],

  'u6/88': [
    { lloc:    TEX`equació`,
      ondiu:   TEX`$|\lambda+4|=\sqrt{6}$`,
      hadedir: TEX`$\dfrac{|\lambda+4|}{\sqrt{6}}=\sqrt{6}$`,
      motiu:   TEX`Hi falta el denominador $\sqrt{6}$ de la fórmula de la distància. La línia següent, $|\lambda+4|=6$, ja és correcta.` },
    { lloc:    TEX`segon punt`,
      ondiu:   TEX`$\lambda+4=-6 \;\rightarrow\; \lambda=-8 \;\rightarrow\; P(-6,19,-8)$`,
      hadedir: TEX`$\lambda+4=-6 \;\rightarrow\; \lambda=-10 \;\rightarrow\; P(-8,23,-10)$`,
      motiu:   TEX`De $\lambda+4=-6$ surt $\lambda=-10$. El punt $(-6,19,-8)$ és a distància $\tfrac{4}{\sqrt{6}}$ del pla, no a $\sqrt{6}$.` },
  ],

  'u6/90': [
    { lloc:    TEX`a)`,
      ondiu:   TEX`$r:\ \dfrac{x}{1}=\dfrac{y+1}{-1}=\dfrac{z+1}{-1}$`,
      hadedir: TEX`$r:\ \dfrac{x}{1}=\dfrac{y+1}{-1}=\dfrac{z-1}{-1}$`,
      motiu:   TEX`La recta passa per $A(0,-1,1)$, on $z=1$. La línia següent, $x=-z+1$, ja és correcta.` },
    { lloc:    TEX`b)`,
      ondiu:   TEX`$d(A,\pi)=\dfrac{|3\cdot(-2)+5\cdot 5-2\cdot(-4)+7|} {\sqrt{3^2+5^2+(-2)^2}}=\dfrac{34}{\sqrt{38}}$ u`,
      hadedir: TEX`$d(A,\pi)=\dfrac{|3\cdot(-2)+5\cdot 1-2\cdot(-4)+7|} {\sqrt{3^2+5^2+(-2)^2}}=\dfrac{14}{\sqrt{38}}$ u`,
      motiu:   TEX`La segona coordenada del punt $A(-2,1,-4)$ és $1$, no $5$. La distància és $\tfrac{14}{\sqrt{38}}=\tfrac{7\sqrt{38}}{19}\approx 2{,}27$ u, que és també la distància de $A$ al punt $Q$ que s'ha trobat.` },
  ],

  'u6/139': [
    { lloc:    TEX`a)`,
      ondiu:   TEX`$r:\ \dfrac{x-1}{1}=\dfrac{y-2}{2}=\dfrac{z-1}{3}$`,
      hadedir: TEX`$r:\ \dfrac{x-1}{1}=\dfrac{y-2}{1}=\dfrac{z-1}{3}$`,
      motiu:   TEX`El vector director de la recta és el normal del pla, $\vec{n}=(1,1,3)$: el segon denominador és $1$.` },
    { lloc:    TEX`b)`,
      ondiu:   TEX`$Q\left(\tfrac{1}{2},\,1,\,-\tfrac{1}{2}\right)$`,
      hadedir: TEX`$Q\left(\tfrac{5}{11},\,\tfrac{16}{11},\,-\tfrac{7}{11}\right)$`,
      motiu:   TEX`Amb la recta correcta, $(1+t,\;2+t,\;1+3t)$, el pla dona $6+11t=0$, és a dir, $t=-\tfrac{6}{11}$.` },
    { lloc:    TEX`c)`,
      ondiu:   TEX`$d(P,\pi)=\sqrt{\dfrac{7}{2}}$ u`,
      hadedir: TEX`$d(P,\pi)=\dfrac{6}{\sqrt{11}}=\dfrac{6\sqrt{11}}{11}$ u`,
      motiu:   TEX`Amb la fórmula, $d=\dfrac{|1+2+3\cdot 1|}{\sqrt{1+1+9}}= \dfrac{6}{\sqrt{11}}\approx 1{,}81$ u. El valor de la solució és la distància de $P$ a un punt del pla que no és el peu de la perpendicular.` },
  ],

  /* ── Unitat 7 · Límits i continuïtat ─────────────────────────────────── */

  'u7/43': [
    { ondiu:   TEX`$g(2)-4<0$`,
      hadedir: TEX`$g(2)=-4<0$`,
      motiu:   TEX`Hi falta el signe igual: $g(2)=3^{-2+2}-5=1-5=-4$. El teorema de Bolzano necessita que $g$ tingui signes diferents als extrems de l'interval, i els té: $g(0)=4>0$ i $g(2)=-4<0$.` },
  ],

  'u7/76': [
    { lloc:    TEX`f)`,
      ondiu:   TEX`$=\dlim_{x\to 3}\dfrac{(3-x)(3+x)}{(x-3)(x+2)} =\dlim_{x\to 3}\dfrac{3-x}{x+2}=0$`,
      hadedir: TEX`$=\dlim_{x\to 3}\dfrac{(3-x)(3+x)}{(x-3)(x+2)} =\dlim_{x\to 3}\dfrac{-(3+x)}{x+2}=-\dfrac{6}{5}$`,
      motiu:   TEX`Els factors que se simplifiquen són $3-x$ i $x-3$, que són oposats: $\dfrac{3-x}{x-3}=-1$. Queda $-\dfrac{3+x}{x+2}$, que en $x=3$ val $-\dfrac{6}{5}$.` },
  ],

  'u7/92': [
    { lloc:    TEX`b)`,
      ondiu:   TEX`$\dlim_{x\to 0^-} f(x)=\dlim_{x\to 0^+} f(x)=0{,}5$ \quad i \quad $f(2)=2{,}5$`,
      hadedir: TEX`$\dlim_{x\to 0^-} f(x)=\dlim_{x\to 0^+} f(x)=1$ \quad i \quad $f(2)=5$`,
      motiu:   TEX`A la gràfica de l'enunciat cada quadre és una unitat (a l'eix $Y$, el $2$ és a la segona marca): el punt buit és a alçada $1$ i la corba passa pel punt $(2,5)$. És la mateixa paràbola de l'apartat d), on el solucionari sí que llegeix $f(-1)=2$ i límit $5$ en $x=2$. La conclusió no canvia: discontinuïtat evitable en $x=0$ i funció contínua en $x=2$.` },
    { lloc:    TEX`e)`,
      ondiu:   TEX`«La funció no és contínua en $x=-2$; té una discontinuïtat de salt finit.»`,
      hadedir: TEX`«La funció no és contínua en $x=2$; té una discontinuïtat de salt finit.»`,
      motiu:   TEX`És la frase que tanca l'estudi del punt $x=2$, on $f(2)=3$ i els límits laterals valen $-1$ i $3$. El punt $x=-2$ ja s'ha estudiat abans, i hi ha un salt infinit.` },
  ],

  'u7/93': [
    { lloc:    TEX`c)`,
      ondiu:   TEX`contínua en el seu domini, $(-\infty,-2)\cup(2,+\infty)$`,
      hadedir: TEX`contínua en el seu domini, $(-\infty,-2]\cup[2,+\infty)$`,
      motiu:   TEX`La condició és $x^2-4\geq 0$, que també es compleix en $x=-2$ i en $x=2$: allà la funció existeix i val $\sqrt{0}=0$. La mateixa solució ho escriu bé just abans ($x\geq 2$, $x\leq -2$).` },
    { lloc:    TEX`g)`,
      ondiu:   TEX`$\dlim_{x\to 1} 2\,|x-1| = 0 = y(0)$`,
      hadedir: TEX`$\dlim_{x\to 1} 2\,|x-1| = 0 = y(1)$`,
      motiu:   TEX`El punt que s'estudia és $x=1$, i $y(1)=2\,|1-1|=0$. En canvi, $y(0)=2$.` },
  ],

  'u7/94': [
    { lloc:    TEX`b)`,
      ondiu:   TEX`$x^2-2x=3\neq 0$ per a qualsevol $x$ real`,
      hadedir: TEX`$x^2-2x+3\neq 0$ per a qualsevol $x$ real`,
      motiu:   TEX`El denominador és $x^2-2x+3$, i no s'anul·la mai perquè el discriminant és negatiu: $(-2)^2-4\cdot 1\cdot 3=-8<0$. Per això la funció és contínua en tot $\R$.` },
    { lloc:    TEX`e), punt $x=-3$`,
      ondiu:   TEX`«No existeix $\dlim_{x\to 3} f(x)$.»`,
      hadedir: TEX`«No existeix $\dlim_{x\to -3} f(x)$.»`,
      motiu:   TEX`Els dos límits laterals que s'acaben de calcular són els del punt $x=-3$.` },
    { lloc:    TEX`e), punt $x=1$`,
      ondiu:   TEX`«La funció té una discontinuïtat evitable en $x=3$.»`,
      hadedir: TEX`«La funció té una discontinuïtat evitable en $x=1$.»`,
      motiu:   TEX`El límit que s'ha calculat és el de $x\to 1$ (val $\tfrac{1}{8}$), i $x=1$ és el zero del denominador que se simplifica. En $x=3$ la funció és contínua.` },
  ],

  'u7/102': [
    { ondiu:   TEX`$\dlim_{x\to -1^-} f(x)=5$`,
      hadedir: TEX`$\dlim_{x\to -1^-} f(x)=-5$`,
      motiu:   TEX`Per a $x<-1$ la funció és $3x-2$, i $3\cdot(-1)-2=-5$. La conclusió no canvia: els límits laterals ($-5$ i $-4$) són diferents i en $x=-1$ hi ha una discontinuïtat de salt finit.` },
  ],

  /* ── Unitat 8 · Derivades ────────────────────────────────────────────── */

  'u8/58': [
    { ondiu:   TEX`«Els punts de tall de la funció amb els eixos són:»`,
      hadedir: TEX`«Els punts de tall de la recta tangent amb els eixos són:»`,
      motiu:   TEX`Els punts que es calculen a continuació, $(0,7)$ i $\left(\tfrac{7}{2},0\right)$, són els talls de la recta tangent $y=-2x+7$, que és la que forma el triangle amb els eixos. La funció $f$ talla els eixos en uns altres punts: $(0,-1)$ i $(-1,0)$.` },
  ],

  /* ── Unitat 9 · Aplicacions de les derivades ─────────────────────────── */

  'u9/41': [
    { ondiu:   TEX`«A $x=$, $f'(x)$ passa de positiva a negativa; per tant, és un màxim.»`,
      hadedir: TEX`«A $x=2$, $f'(x)$ passa de positiva a negativa; per tant, és un màxim.»`,
      motiu:   TEX`Hi falta el valor de $x$. És l'últim dels quatre punts on la derivada val $0$ ($x=-4$, $x=-2$, $x=0$ i $x=2$), i a la gràfica $f'$ hi passa de positiva a negativa.` },
  ],

  'u9/42': [
    { lloc:    TEX`d), valor de $y'(2)$`,
      ondiu:   TEX`$y'(2)=80-60-20>0$`,
      hadedir: TEX`$y'(2)=80-60=20>0$`,
      motiu:   TEX`$y'(2)=5\cdot 2^4-15\cdot 2^2=80-60=20$. Tal com està imprès, $80-60-20$ valdria $0$.` },
    { lloc:    TEX`d), extrems relatius`,
      ondiu:   TEX`«Té màxims relatius a $x=-\sqrt{3}$, $x=\sqrt{3}$.»`,
      hadedir: TEX`«Té un màxim relatiu a $x=-\sqrt{3}$ i un mínim relatiu a $x=\sqrt{3}$.»`,
      motiu:   TEX`A $x=-\sqrt{3}$ la funció passa de créixer a decréixer (màxim), però a $x=\sqrt{3}$ passa de decréixer a créixer: hi ha un mínim. A $x=0$ la derivada també s'anul·la, però no canvia de signe i no hi ha extrem.` },
  ],

  'u9/51': [
    { ondiu:   TEX`«El signe de $y$ és constant.»`,
      hadedir: TEX`«El signe de $y'$ és constant.»`,
      motiu:   TEX`La que no s'anul·la mai i és contínua és la derivada $y'(x)=3x^2-4x+6$, i per això té signe constant (positiu, perquè $y'(0)=6>0$). La funció $y$ sí que canvia de signe: per exemple, $y(0)=-13$ i $y(3)=14$.` },
  ],

  'u9/58': [
    { lloc:    TEX`b)`,
      ondiu:   TEX`$y'(x)=0 \;\rightarrow\; a=\pm 2$`,
      hadedir: TEX`$y'(x)=0 \;\rightarrow\; x=\pm 2$`,
      motiu:   TEX`El que es resol és $3x^2-12=0$, i la incògnita és $x$. El paràmetre $a$ ja s'ha trobat a l'apartat a) i val $-12$.` },
  ],

  'u9/67': [
    { lloc:    TEX`d)`,
      ondiu:   TEX`$y''=-\dfrac{6}{x^2}$`,
      hadedir: TEX`$y''=-\dfrac{6}{x^4}$`,
      motiu:   TEX`Com que $y'=\dfrac{x^3+2}{x^3}=1+2x^{-3}$, la derivada segona és $y''=-6x^{-4}$. La conclusió no canvia: $y''<0$ per a tot $x\neq 0$ i la funció és còncava a $(-\infty,0)$ i a $(0,+\infty)$.` },
    { lloc:    TEX`f)`,
      ondiu:   TEX`«$y''>0$ a $(-\infty,-2)$ i a $(2,+\infty)$ $\rightarrow$ $y$ és convexa a $(-\infty,-2)$ i a $(2,+\infty)$.»`,
      hadedir: TEX`Aquestes dues línies sobren.`,
      motiu:   TEX`El domini de la funció és $[-2,2]$, com diu la mateixa solució: fora d'aquest interval la funció no existeix i no té sentit parlar-ne de la curvatura. La resposta és només que $y$ és còncava a $(-2,2)$.` },
    { lloc:    TEX`h)`,
      ondiu:   TEX`$y''(x)=\dfrac{2(x^2-x)-(2x-1)^2}{(x^2-x)}$`,
      hadedir: TEX`$y''(x)=\dfrac{2(x^2-x)-(2x-1)^2}{(x^2-x)^2}$`,
      motiu:   TEX`En derivar el quocient, el denominador queda elevat al quadrat. El pas següent de la solució ja el porta bé, perquè $x^2(x-1)^2=(x^2-x)^2$.` },
    { lloc:    TEX`n)`,
      ondiu:   TEX`$y''(x)>0$ a $\left(-\tfrac{\pi}{4},\tfrac{\pi}{4}\right)$ i a $\left(\tfrac{\pi}{4},\tfrac{\pi}{2}\right)$;\quad $y''(x)<0$ a $\left(-\tfrac{\pi}{2},-\tfrac{\pi}{4}\right)$`,
      hadedir: TEX`$y''(x)>0$ a $\left(-\tfrac{\pi}{4},\tfrac{\pi}{4}\right)$;\quad $y''(x)<0$ a $\left(-\tfrac{\pi}{2},-\tfrac{\pi}{4}\right)$ i a $\left(\tfrac{\pi}{4},\tfrac{\pi}{2}\right)$`,
      motiu:   TEX`$y''=2\cos 2x$. A l'interval $\left(\tfrac{\pi}{4},\tfrac{\pi}{2}\right)$ l'angle $2x$ és entre $\tfrac{\pi}{2}$ i $\pi$, on el cosinus és negatiu. Per tant, la funció és convexa a $\left(-\tfrac{\pi}{4},\tfrac{\pi}{4}\right)$ i còncava als altres dos intervals.` },
  ],

  /* ── Unitat 10 · Representació de funcions ───────────────────────────── */

  'u10/37': [
    { ondiu:   TEX`«$f'(x)>0$ en $(-\infty,-2)\cup(2,6)$» \; i \; «$f'(x)<0$ en $(-2,2)\cup(6,+\infty)$»`,
      hadedir: TEX`«$f'(x)>0$ en $(-\infty,x_1)\cup(x_2,x_3)$» \; i \; «$f'(x)<0$ en $(x_1,x_2)\cup(x_3,+\infty)$»`,
      motiu:   TEX`El signe de $f'$ canvia als punts on la gràfica talla l'eix $X$, que l'enunciat anomena $x_1$, $x_2$ i $x_3$ i que la mateixa solució fa servir a la línia següent. A la gràfica, $x_1$ és entre $-2$ i $-1$ i $x_3$ entre $5$ i $6$: no són $-2$ ni $6$.` },
  ],

  'u10/38': [
    { enunciat: 1,
      ondiu:   TEX`«Creixement: $(-\infty,0)\cup(2\;-\infty)$.»`,
      hadedir: TEX`«Creixement: $(-\infty,0)\cup(2,+\infty)$.»`,
      motiu:   TEX`És una errada de l'enunciat. La funció creix abans del màxim $(0,0)$ i després del mínim $(2,4)$, com es veu a la gràfica de la solució.` },
  ],

  'u10/41': [
    { ondiu:   TEX`«$f'(x)=\dfrac{-x^2-1}{(x^2-1)^2}<0 \;\rightarrow\; f(x)$ creixent»`,
      hadedir: TEX`«$f'(x)=\dfrac{-x^2-1}{(x^2-1)^2}<0 \;\rightarrow\; f(x)$ decreixent»`,
      motiu:   TEX`Si la derivada és negativa, la funció decreix. És el que es veu a la gràfica de la mateixa solució, on les tres branques baixen.` },
  ],

  'u10/45': [
    { lloc:    TEX`b)`,
      ondiu:   TEX`$\mathrm{Dom}\,f=\R-\{3\}$`,
      hadedir: TEX`$\mathrm{Dom}\,f=\R-\{-3\}$`,
      motiu:   TEX`El denominador és $x+3$, que s'anul·la en $x=-3$.` },
  ],

  'u10/62': [
    { lloc:    TEX`c)`,
      ondiu:   TEX`$\dlim_{x\to-\infty}\,(x^4+2x^3-2x-1)=-\infty$`,
      hadedir: TEX`$\dlim_{x\to-\infty}\,(x^4+2x^3-2x-1)=+\infty$`,
      motiu:   TEX`El terme dominant és $x^4$, que és positiu tant si $x\to-\infty$ com si $x\to+\infty$.` },
    { lloc:    TEX`d)`,
      ondiu:   TEX`$\dlim_{x\to+\infty}\,(-2x^4+3x^2-x-1)=+\infty$`,
      hadedir: TEX`$\dlim_{x\to+\infty}\,(-2x^4+3x^2-x-1)=-\infty$`,
      motiu:   TEX`El terme dominant és $-2x^4$, que tendeix a $-\infty$ tant si $x\to-\infty$ com si $x\to+\infty$.` },
  ],

  'u10/63': [
    { lloc:    TEX`c)`,
      ondiu:   TEX`$\dlim_{x\to-\infty}\dfrac{2x}{x+1}=2$ \; i \; $\dlim_{x\to+\infty}\dfrac{2x}{x+1}=2$`,
      hadedir: TEX`$\dlim_{x\to-\infty}\dfrac{4x^2}{x^2-9}=4$ \; i \; $\dlim_{x\to+\infty}\dfrac{4x^2}{x^2-9}=4$`,
      motiu:   TEX`Els límits que hi ha impresos són d'una altra funció. Amb la de l'apartat, $y=\dfrac{4x^2}{x^2-9}$, el límit és $4$, que és el que dona l'asímptota horitzontal $y=4$ de la mateixa solució.` },
  ],

  'u10/75': [
    { lloc:    TEX`a), signe de la derivada`,
      ondiu:   TEX`«En $(-5,1)$, $y'>0$ $\rightarrow$ Funció decreixent»`,
      hadedir: TEX`«En $(-5,1)$, $y'<0$ $\rightarrow$ Funció decreixent»`,
      motiu:   TEX`Entre les dues arrels la derivada és negativa: per exemple, $y'(0)=-15$.` },
    { lloc:    TEX`a), màxim`,
      ondiu:   TEX`$x=-5 \;\rightarrow\; y=203 \;\rightarrow\; (-5,203)$ màxim`,
      hadedir: TEX`$x=-5 \;\rightarrow\; y=103 \;\rightarrow\; (-5,103)$ màxim`,
      motiu:   TEX`$y(-5)=(-5)^3+6\cdot(-5)^2-15\cdot(-5)+3=-125+150+75+3=103$.` },
    { lloc:    TEX`b)`,
      ondiu:   TEX`$x=-\tfrac{1}{2} \rightarrow y=-6 \rightarrow \left(-\tfrac{1}{2},-6\right)$ màxim;\quad $x=-\tfrac{1}{2} \rightarrow y=6 \rightarrow \left(-\tfrac{1}{2},6\right)$ mínim`,
      hadedir: TEX`$x=-\tfrac{1}{2} \rightarrow y=-4 \rightarrow \left(-\tfrac{1}{2},-4\right)$ màxim;\quad $x=\tfrac{1}{2} \rightarrow y=4 \rightarrow \left(\tfrac{1}{2},4\right)$ mínim`,
      motiu:   TEX`El numerador val $4\cdot\tfrac{1}{4}+1=2$ en tots dos punts, i $2:\tfrac{1}{2}=4$. Per tant, $y\left(\tfrac{1}{2}\right)=4$ i $y\left(-\tfrac{1}{2}\right)=-4$. A més, el mínim és a $x=\tfrac{1}{2}$, no a $x=-\tfrac{1}{2}$.` },
    { lloc:    TEX`d)`,
      ondiu:   TEX`«$y'=4x^3-72x^2=0 \rightarrow x=0$. En $\R-\{0\}$, $y'<0$ $\rightarrow$ Funció decreixent»`,
      hadedir: TEX`«$y'=4x^3-72x^2=0 \rightarrow x=0$, $x=18$. En $(-\infty,0)\cup(0,18)$, $y'<0$ $\rightarrow$ Funció decreixent. En $(18,+\infty)$, $y'>0$ $\rightarrow$ Funció creixent. $x=18 \rightarrow y=-34\,992 \rightarrow (18,-34\,992)$ mínim»`,
      motiu:   TEX`$y'=4x^2(x-18)$ també s'anul·la en $x=18$, i allà passa de negativa a positiva. En $x=0$ la derivada val $0$ però no canvia de signe: no hi ha extrem.` },
  ],

  'u10/78': [
    { lloc:    TEX`b), domini`,
      ondiu:   TEX`$\mathrm{Dom}=\R$`,
      hadedir: TEX`$\mathrm{Dom}=\R-\{-2\}$`,
      motiu:   TEX`El denominador $x+2$ s'anul·la en $x=-2$.` },
    { lloc:    TEX`b), interval`,
      ondiu:   TEX`«En $(-\infty,2)$, $y''>0$ $\rightarrow$ Funció convexa»`,
      hadedir: TEX`«En $(-\infty,-2)$, $y''>0$ $\rightarrow$ Funció convexa»`,
      motiu:   TEX`$y''=\dfrac{-8}{(x+2)^3}$ canvia de signe en $x=-2$: és positiva per a $x<-2$ i negativa per a $x>-2$.` },
    { lloc:    TEX`d), derivada segona`,
      ondiu:   TEX`$y''=\dfrac{12x^2+4x}{(x^2-1)^3}\neq 0$`,
      hadedir: TEX`$y''=\dfrac{12x^2+4}{(x^2-1)^3}\neq 0$`,
      motiu:   TEX`El numerador és $12x^2+4$, que no s'anul·la mai. Amb $4x$ s'anul·laria en $x=0$, i la solució no podria dir que $y''\neq 0$.` },
    { lloc:    TEX`d), interval`,
      ondiu:   TEX`«En $(1,1)$, $y''<0$ $\rightarrow$ Funció còncava»`,
      hadedir: TEX`«En $(-1,1)$, $y''<0$ $\rightarrow$ Funció còncava»`,
      motiu:   TEX`Entre $-1$ i $1$ el denominador $(x^2-1)^3$ és negatiu i el numerador és positiu.` },
  ],

  'u10/84': [
    { lloc:    TEX`d)`,
      ondiu:   TEX`$f\left(\tfrac{2}{3}\right)=\dfrac{26}{27} \;\rightarrow\; \left(\tfrac{2}{3},\tfrac{26}{27}\right)$ punt d'inflexió`,
      hadedir: TEX`$f\left(\tfrac{2}{3}\right)=\dfrac{20}{27} \;\rightarrow\; \left(\tfrac{2}{3},\tfrac{20}{27}\right)$ punt d'inflexió`,
      motiu:   TEX`$f\left(\tfrac{2}{3}\right)=\tfrac{8}{27}-\tfrac{24}{27}-\tfrac{18}{27} +\tfrac{54}{27}=\tfrac{20}{27}$.` },
    { lloc:    TEX`g)`,
      ondiu:   TEX`«$f''(x)=-2>0$ \; $\forall x\in\R$»`,
      hadedir: TEX`«$f''(x)=-2<0$ \; $\forall x\in\R$»`,
      motiu:   TEX`$-2$ és negatiu, i per això la funció és còncava, com diu la mateixa solució.` },
  ],

  'u10/100': [
    { lloc:    TEX`a)`,
      ondiu:   TEX`$y''=\dfrac{-1}{2(2-x)\sqrt{2-x}}<0$`,
      hadedir: TEX`$y''=\dfrac{-1}{4(2-x)\sqrt{2-x}}<0$`,
      motiu:   TEX`De $y'=-\tfrac{1}{2}(2-x)^{-1/2}$ surt $y''=-\tfrac{1}{4}(2-x)^{-3/2}$. La conclusió (funció còncava) no canvia.` },
    { lloc:    TEX`c), límit`,
      ondiu:   TEX`$\dlim_{x\to-\infty}\dfrac{\sqrt{x^2-9}}{x}=1 \;\rightarrow\; m=-1$`,
      hadedir: TEX`$\dlim_{x\to-\infty}\dfrac{\sqrt{x^2-9}}{x}=-1 \;\rightarrow\; m=-1$`,
      motiu:   TEX`Quan $x\to-\infty$, el numerador és positiu i el denominador negatiu: el límit és $-1$, que és el pendent $m$ que la solució fa servir.` },
    { lloc:    TEX`c), títol`,
      ondiu:   TEX`«Creixement i decreixement:» (a sobre de la derivada segona)`,
      hadedir: TEX`«Concavitat i convexitat:»`,
      motiu:   TEX`El títol «Creixement i decreixement» hi surt dues vegades. La segona, la que porta $y''$, és l'estudi de la curvatura.` },
    { lloc:    TEX`d)`,
      ondiu:   TEX`$y''=\dfrac{-1}{4(x+3)\sqrt{x+3}}>0$`,
      hadedir: TEX`$y''=\dfrac{1}{4(x+3)\sqrt{x+3}}>0$`,
      motiu:   TEX`De $y'=-\tfrac{1}{2}(x+3)^{-1/2}$ surt $y''=\tfrac{1}{4}(x+3)^{-3/2}$, que és positiva. La conclusió (funció convexa) és correcta.` },
  ],

  'u10/108': [
    { lloc:    TEX`b)`,
      ondiu:   TEX`«Eix $Y$: $f(0)=0 \;\rightarrow\; (0,6)$»`,
      hadedir: TEX`«Eix $Y$: $f(0)=6 \;\rightarrow\; (0,6)$»`,
      motiu:   TEX`Per a $x>-2$ la funció és $6-x^2$, i $f(0)=6$. El punt $(0,6)$ ja és correcte.` },
    { lloc:    TEX`c), continuïtat`,
      ondiu:   TEX`$\dlim_{x\to-2^-}f(x)=\dlim_{x\to 2^-}(x^3-1)=7$`,
      hadedir: TEX`$\dlim_{x\to 2^-}f(x)=\dlim_{x\to 2^-}(x^3-1)=7$`,
      motiu:   TEX`El punt que s'estudia és $x=2$, on canvia l'expressió de la funció.` },
    { lloc:    TEX`c), derivada segona`,
      ondiu:   TEX`$\dfrac{14}{(x-1)^3}$ \; si \; $x<2$`,
      hadedir: TEX`$\dfrac{14}{(x-1)^3}$ \; si \; $x>2$`,
      motiu:   TEX`És la derivada segona del tercer tros, $\dfrac{7}{x-1}$, que és el de $x>2$.` },
    { lloc:    TEX`d)`,
      ondiu:   TEX`«$2-3\cos x=0 \;\rightarrow\; x=\arccos\left(\tfrac{2}{3}\right) \;\rightarrow\; \left(\arccos\left(\tfrac{2}{3}\right),0\right)$»`,
      hadedir: TEX`«$2-3\cos x=0 \;\rightarrow\; x=\pm\arccos\left(\tfrac{2}{3}\right)+2k\pi$, amb $x\leq 0$. El tall més proper a l'origen és $\left(-\arccos\left(\tfrac{2}{3}\right),0\right)$»`,
      motiu:   TEX`El tros $2-3\cos x$ només val per a $x\leq 0$, i $\arccos\left(\tfrac{2}{3}\right)\approx 0{,}84$ és positiu: allà la funció és $2^{-x+1}-3$ i no val $0$. Els talls amb l'eix $X$ són tots a l'esquerra de l'origen i n'hi ha infinits, com es veu a la gràfica de la solució.` },
  ],

  /* ── Unitat 11 · Integrals ───────────────────────────────────────────── */

  'u11/52': [
    { lloc:    TEX`g)`,
      ondiu:   TEX`$\displaystyle\int (x-1)^3\,dx=\dfrac{(x-1)^3}{4}+k$`,
      hadedir: TEX`$\displaystyle\int (x-1)^3\,dx=\dfrac{(x-1)^4}{4}+k$`,
      motiu:   TEX`En integrar una potència, l'exponent augmenta una unitat.` },
  ],

  'u11/54': [
    { lloc:    TEX`a)`,
      ondiu:   TEX`$\displaystyle\int\dfrac{4}{x-2}\,dx=4\ln|x+2|+k$`,
      hadedir: TEX`$\displaystyle\int\dfrac{4}{x-2}\,dx=4\ln|x-2|+k$`,
      motiu:   TEX`El denominador és $x-2$.` },
    { lloc:    TEX`d)`,
      ondiu:   TEX`$\displaystyle\int\dfrac{1}{(x+4)^2}\,dx=-\dfrac{1}{x-4}+k$`,
      hadedir: TEX`$\displaystyle\int\dfrac{1}{(x+4)^2}\,dx=-\dfrac{1}{x+4}+k$`,
      motiu:   TEX`El denominador és $x+4$.` },
    { lloc:    TEX`f)`,
      ondiu:   TEX`$\displaystyle\int\left(\dfrac{2}{(x+3)^3}+\dfrac{5}{(x-3)^2}\right)dx =\dfrac{-1}{(x+3)^2}-\dfrac{5}{x-3}+k$`,
      hadedir: TEX`$\displaystyle\int\left(\dfrac{2}{(x+3)^3}-\dfrac{5}{(x-3)^2}\right)dx =\dfrac{-1}{(x+3)^2}+\dfrac{5}{x-3}+k$`,
      motiu:   TEX`A l'enunciat, el segon terme porta signe menys. La solució el copia amb signe més, i el resultat que dona és el d'aquesta altra integral.` },
  ],

  /* ── Unitat 12 · La integral definida ────────────────────────────────── */

  'u12/55': [
    { lloc:    TEX`c)`,
      ondiu:   TEX`$=\dfrac{9}{4}\sqrt[3]{9}+\dfrac{195}{12}$`,
      hadedir: TEX`$=\dfrac{27}{4}\sqrt[3]{9}+\dfrac{199}{12}$`,
      motiu:   TEX`$\tfrac{3}{4}\sqrt[3]{9^4}=\tfrac{3}{4}\cdot 9\sqrt[3]{9}= \tfrac{27}{4}\sqrt[3]{9}$ \;i\; $18-\tfrac{3}{4}-\tfrac{2}{3}=\tfrac{199}{12}$. El valor és aproximadament $30{,}62$.` },
    { lloc:    TEX`g)`,
      ondiu:   TEX`$\displaystyle\int_0^{\pi}\cos 2x\,dx$`,
      hadedir: TEX`$\displaystyle\int_0^{\pi}\cos^2 x\,dx$`,
      motiu:   TEX`L'enunciat demana la integral de $\cos^2 x$, i la primitiva $\tfrac{x}{2}+\tfrac{\sin 2x}{4}$ i el resultat $\tfrac{\pi}{2}$ són els d'aquesta funció. La integral de $\cos 2x$ entre $0$ i $\pi$ valdria $0$.` },
  ],

  /* ── Unitat 13 · Probabilitat ────────────────────────────────────────── */

  'u13/40': [
    { lloc:    TEX`a)`,
      ondiu:   TEX`$VR_{5,6}=5^6=15\,625$`,
      hadedir: TEX`$4\cdot VR_{5,5}=4\cdot 5^5=12\,500$`,
      motiu:   TEX`Els dígits parells són $0$, $2$, $4$, $6$ i $8$, però un nombre de 6 xifres no pot començar per $0$: per a la primera xifra només hi ha 4 opcions. El resultat $15\,625$ compta també seqüències com $002468$, que no són nombres de 6 xifres.` },
  ],

  'u13/60': [
    { lloc:    TEX`a)`,
      ondiu:   TEX`$P(A\cap B)=1-P(\overline{A}\cap\overline{B})=1-0{,}3=0{,}7$`,
      hadedir: TEX`$P(A\cup B)=1-P(\overline{A}\cap\overline{B})=1-0{,}3=0{,}7$`,
      motiu:   TEX`«No s'ha complert alguna de les dues normes» és la unió $A\cup B$, que és el contrari de $\overline{A}\cap\overline{B}$ (complir-les totes dues). La intersecció val una altra cosa: $P(A\cap B)=0{,}23+0{,}65-0{,}7=0{,}18$.` },
  ],

  /* ── Unitat 14 · Distribucions de probabilitat ───────────────────────── */

  'u14/53': [
    { lloc:    TEX`b)`,
      ondiu:   TEX`$P(X=3)=0{,}188$`,
      hadedir: TEX`$P(X=12)=0{,}000000007$`,
      motiu:   TEX`$X$ compta els enquestats que responen «NS/NC». Si exactament 3 no responen «NS/NC», els altres 12 sí que ho fan: cal $P(X=12)=\binom{15}{12}\cdot 0{,}13^{12}\cdot 0{,}87^{3}\approx 7\cdot 10^{-9}$. El valor $0{,}188$ és la probabilitat que exactament 3 responguin «NS/NC»: seria la resposta si a l'enunciat hi sobrés el «no».` },
  ],

};


/* ═══════════════════════════════════════════════════════════════════════
   LES OBSERVACIONS
   ───────────────────────────────────────────────────────────────────────
   Comentaris que no són errades, però que poden confondre. Només es veuen
   si ERRADES_OBS és true: surten dins de l'exercici, sota les errades.

     'u9/66': [
       { lloc: TEX`c) i d)`,
         text: TEX`Les respostes són el nombre màxim.` },
     ],

   `lloc` és opcional, igual que a les errades. Una observació que parla de
   dos exercicis està escrita dues vegades, un cop a cada exercici.
   ═══════════════════════════════════════════════════════════════════════ */

const OBSERVACIONS = {

  /* ── Unitat 1 · Matrius ──────────────────────────────────────────────── */

  'u1/42': [
    { text: TEX`L'enunciat demana dos exemples de cada tipus de matriu i la solució només en dona un.` },
  ],

  /* ── Unitat 2 · Determinants ─────────────────────────────────────────── */

  'u2/44': [
    { text: TEX`A l'enunciat hi ha una paraula repetida: «perquè que el determinant» ha de ser «perquè el determinant».` },
  ],

  /* ── Unitat 3 · Sistemes d'equacions ─────────────────────────────────── */

  'u3/60': [
    { lloc: TEX`d) i e)`,
      text: TEX`Dues errades tipogràfiques sense importància: a d) hi diu «Rango ($A$)» en lloc de «Rang ($A$)», i a e), a «Si $m\neq 1$, $m$ $\rightarrow$», hi sobra la segona $m$.` },
  ],

  'u3/64': [
    { text: TEX`L'enunciat demana resoldre el sistema quan és compatible indeterminat ($a=1$) i la solució només el discuteix. Per a $a=1$ el sistema és $2x+y+z=2$, $x+y=1$, $-y+z=0$, i les solucions són $x=1-\lambda$, $y=\lambda$, $z=\lambda$ amb $\lambda\in\R$.` },
  ],

  /* ── Unitat 5 · Rectes i plans en l'espai ────────────────────────────── */

  'u5/76': [
    { lloc: TEX`b)`,
      text: TEX`La solució escriu «$M^*=(\ldots)=2$» i «$M^*=(\ldots)=3$». Vol dir que el rang de $M^*$ és $2$ o $3$: una matriu no és igual a un nombre.` },
  ],

  'u5/77': [
    { text: TEX`La solució escriu «$M^*=(\ldots)=2$» i «$M^*=(\ldots)=3$». Vol dir que el rang de $M^*$ és $2$ o $3$: una matriu no és igual a un nombre.` },
  ],

  /* ── Unitat 7 · Límits i continuïtat ─────────────────────────────────── */

  'u7/68': [
    { text: TEX`A la solució, els apartats c) i d) surten en ordre canviat: primer el d) i després el c). Els valors de cadascun són correctes.` },
  ],

  'u7/113': [
    { text: TEX`El valor $x=-3$ és una arrel exacta, perquè $x^3+6x^2+12x+9=(x+2)^3+1$. Si proves amb $x=-3$ trobaràs $f(-3)=0$ en lloc d'un canvi de signe: no t'has equivocat, has trobat l'arrel. Qualsevol interval de longitud $2$ que la contingui, com ara $(-4,-2)$, respon la pregunta.` },
  ],

  'u7/120': [
    { text: TEX`L'enunciat anomena $f(x)=x+1$, i la solució torna a fer servir la lletra $f$ per a una funció diferent: la resta de les dues funcions que es tallen (per exemple, $f(x)=x+1-e^{x-1}$ a l'apartat a). El punt on aquesta resta val zero és l'abscissa del punt de tall. D'altra banda, l'enunciat només demana demostrar que hi ha un punt de tall; la solució va més enllà i l'aproxima amb un error menor que una dècima.` },
  ],

  /* ── Unitat 8 · Derivades ────────────────────────────────────────────── */

  'u8/54': [
    { text: TEX`L'enunciat escriu la recta com a $f(x)=2x-123$, amb la mateixa lletra $f$ de la funció $f(x)=x^3-x+4$. Són dues coses diferents: la recta és $y=2x-123$, que és com l'escriu la solució.` },
  ],

  'u8/58': [
    { text: TEX`A la solució hi ha una errada tipogràfica sense importància: hi diu «traingle» en lloc de «triangle».` },
  ],

  'u8/87': [
    { text: TEX`L'enunciat demana calcular la funció derivada «utilitzant la definició», però el solucionari només hi dona el resultat final de cada apartat, sense el desenvolupament. Els resultats són correctes. Si vols veure un model del desenvolupament pas a pas, mira la solució de l'exercici 88.` },
  ],

  /* ── Unitat 9 · Aplicacions de les derivades ─────────────────────────── */

  'u9/39': [
    { lloc: TEX`b)`,
      text: TEX`On diu «La derivada té un grau» vol dir «La derivada té grau u»: la derivada d'una paràbola és un polinomi de grau $1$, que s'anul·la en un sol punt, i per això la paràbola té, com a molt, un extrem.` },
  ],

  'u9/41': [
    { text: TEX`L'enunciat diu «A partir de la derivada de $f'(x)$». Vol dir: a partir de la gràfica de la derivada $f'(x)$, que és la que es dona.` },
  ],

  'u9/51': [
    { text: TEX`La primera frase de la solució enuncia la implicació al revés. El que es fa servir és: si $y'(x)>0$ per a tot $x$, llavors la funció és sempre creixent. La implicació contrària no és certa en general: $y=x^3$ és sempre creixent i, en canvi, $y'(0)=0$.` },
  ],

  'u9/66': [
    { lloc: TEX`c) i d)`,
      text: TEX`Les respostes «Dos punts d'inflexió» i «$n-2$ punts d'inflexió» són el nombre màxim. Un polinomi de quart grau en pot tenir dos o cap: per exemple, $y=x^4$ no en té cap, perquè $y''=12x^2$ no canvia de signe.` },
  ],

  /* ── Unitat 10 · Representació de funcions ───────────────────────────── */

  'u10/75': [
    { lloc: TEX`e)`,
      text: TEX`La solució estudia el creixement, però no diu l'extrem relatiu que demana l'enunciat: hi ha un mínim a $(0,1)$.` },
  ],

  'u10/84': [
    { lloc: TEX`d)`,
      text: TEX`Al segon extrem, $\left(\tfrac{2+\sqrt{7}}{3},\tfrac{20-14\sqrt{7}}{27}\right)$, la solució no diu de quin tipus és: és un mínim.` },
  ],

  'u10/108': [
    { lloc: TEX`b) i c)`,
      text: TEX`La solució només hi dona els mínims. També hi ha màxims relatius: a b), el punt $(0,6)$; a c), el punt $(2,7)$, on la funció passa de créixer a decréixer.` },
  ],

  'u10/124': [
    { lloc: TEX`c)`,
      text: TEX`La solució escriu $T'(x)$ i $T(x)$ en lloc de $T'(t)$ i $T(t)$, i dona l'interval $(-\infty,2)$ tot i que el temps comença a $t=0$.` },
  ],

  /* ── Unitat 13 · Probabilitat ────────────────────────────────────────── */

  'u13/35': [
    { text: TEX`A la solució hi ha una errada tipogràfica sense importància: hi diu «probabiltat» en lloc de «probabilitat».` },
  ],

  'u13/36': [
    { text: TEX`A les solucions hi ha dues errades tipogràfiques sense importància: «probabiltat» en lloc de «probabilitat» (exercici 36) i «perfeccionamient» en lloc de «perfeccionament» (exercici 96).` },
  ],

  'u13/96': [
    { text: TEX`A les solucions hi ha dues errades tipogràfiques sense importància: «probabiltat» en lloc de «probabilitat» (exercici 36) i «perfeccionamient» en lloc de «perfeccionament» (exercici 96).` },
  ],

  /* ── Unitat 14 · Distribucions de probabilitat ───────────────────────── */

  'u14/46': [
    { text: TEX`A les solucions hi ha dues errades tipogràfiques sense importància: «propabilitat» en lloc de «probabilitat» (exercici 46 a) i, a l'exercici 50, un parèntesi que no es tanca: ha de dir $1-\bigl(P(X=0)+P(X=1)+P(X=2)\bigr)$.` },
  ],

  'u14/50': [
    { text: TEX`A les solucions hi ha dues errades tipogràfiques sense importància: «propabilitat» en lloc de «probabilitat» (exercici 46 a) i, a l'exercici 50, un parèntesi que no es tanca: ha de dir $1-\bigl(P(X=0)+P(X=1)+P(X=2)\bigr)$.` },
  ],

};


/* ═══════════════════════════════════════════════════════════════════════
   A PARTIR D'AQUÍ NO CAL QUE TOQUIS RES
   ═══════════════════════════════════════════════════════════════════════ */

/* Les dues comandes pròpies de defs.tex que fan servir els textos. */
const ERRADES_MACROS = { '\\dlim': '\\displaystyle\\lim', '\\R': '\\mathbb{R}' };

/* Les errades d'un exercici (llista buida si no en té). */
function erradesDe(u, n){
  return ERRADES[u + '/' + n] || [];
}

/* Les observacions d'un exercici. Cap, si l'interruptor és apagat. */
function observacionsDe(u, n){
  return ERRADES_OBS ? (OBSERVACIONS[u + '/' + n] || []) : [];
}

/* La icona d'avís: un triangle amb un signe d'admiració. Es dibuixa aquí, i
   no amb el caràcter ⚠, perquè es vegi igual a tots els mòbils i ordinadors. */
const _ICONA_AVIS = '<svg class="err-ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
  + '<path d="M12 3.6 21.7 20.4H2.3Z" fill="currentColor" stroke="currentColor" stroke-width="2.6" stroke-linejoin="round"/>'
  + '<path d="M12 9.4v5" fill="none" stroke="#fff" stroke-width="2.3" stroke-linecap="round"/>'
  + '<circle cx="12" cy="18" r="1.35" fill="#fff"/></svg>';

/* L'avís que surt a la targeta de l'exercici, a la llista de la tasca:
   «2 errades al solucionari». Només compta les errades de la SOLUCIÓ: les
   d'enunciat es mostren senceres allà mateix (vegeu htmlErradesEnunciat).
   Cadena buida si la solució no té cap errada. */
function avisErrades(u, n){
  const k = erradesDe(u, n).filter(e => !e.enunciat).length;
  if(!k) return '';
  return k === 1 ? '1 errada al solucionari' : k + ' errades al solucionari';
}

function htmlAvisErrades(u, n){
  const text = avisErrades(u, n);
  return text ? '<span class="ex-err">' + _ICONA_AVIS + '<span>' + text + '</span></span>' : '';
}

/* ── De text amb fórmules a HTML ──────────────────────────────────────── */

function _escapa(s){
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/* Un tros de text normal (fora dels dòlars). */
function _textAHtml(t){
  return _escapa(t)
    .replace(/\\quad\s*/g, '&emsp;')
    .replace(/\\;/g, '&ensp;')
    .replace(/\\,/g, '&thinsp;')
    .replace(/\\([$%])/g, '$1');
}

/* Una fórmula (el que hi ha entre dos dòlars), amb la puntuació que porta
   enganxada: `abans` («, parèntesi d'obrir) i `despres` (punt, coma, »...).
   Aquesta puntuació es posa DINS de la fórmula perquè, en pantalles estretes,
   no quedi mai sola en una altra línia.
   Si KaTeX no s'ha pogut carregar, es mostra el LaTeX tal qual: es llegeix
   pitjor, però no es perd res. */
const _KATEX_FI   = '</span></span></span>';     // tanca l'últim tros, .katex-html i .katex
const _KATEX_TROS = '<span class="base">';       // obre el primer tros de la fórmula

function _formulaAHtml(tex, abans, despres){
  abans = abans || ''; despres = despres || '';
  let h = null;
  if(typeof katex !== 'undefined'){
    try{
      h = katex.renderToString(tex, {
        throwOnError: false,
        macros: Object.assign({}, ERRADES_MACROS)
      });
    }catch(e){ h = null; }
  }
  if(h === null){
    return _escapa(abans) + '<code class="err-tex">' + _escapa(tex) + '</code>' + _escapa(despres);
  }
  if(despres && h.endsWith(_KATEX_FI)){
    h = h.slice(0, -_KATEX_FI.length) + '<span class="err-punt">' + _escapa(despres) + '</span>' + _KATEX_FI;
    despres = '';
  }
  const i = abans ? h.indexOf(_KATEX_TROS) : -1;
  if(i >= 0){
    const tall = i + _KATEX_TROS.length;
    h = h.slice(0, tall) + '<span class="err-punt">' + _escapa(abans) + '</span>' + h.slice(tall);
    abans = '';
  }
  return _escapa(abans) + h + _escapa(despres);
}

/* Text amb fórmules entre $...$  →  HTML. */
function texAHtml(s){
  if(!s) return '';
  s = String(s);

  /* 1) Es talla en trossos: text, fórmula, text, fórmula... */
  const trossos = [];
  let tros = '', mates = false;
  for(let i = 0; i < s.length; i++){
    const c = s[i];
    if(c === '\\' && i + 1 < s.length){ tros += c + s[i + 1]; i++; continue; }
    if(c === '$'){
      trossos.push({mates: mates, s: tros});
      tros = ''; mates = !mates;
      continue;
    }
    tros += c;
  }
  /* Si ha quedat un dòlar sense tancar, el que venia darrere es mostra com
     a text, amb el dòlar al davant, perquè es vegi que falta l'altre. */
  trossos.push({mates: false, s: (mates ? '$' : '') + tros});

  /* 2) Cada fórmula s'emporta la puntuació que té enganxada a banda i banda. */
  let html = '';
  for(let i = 0; i < trossos.length; i++){
    const t = trossos[i];
    if(!t.mates){ html += _textAHtml(t.s); continue; }
    let abans = '', despres = '';
    const m = /[«(\[¿¡]+$/.exec(html);
    if(m){ abans = m[0]; html = html.slice(0, m.index); }
    const seg = trossos[i + 1];
    if(seg && !seg.mates){
      const d = /^[.,;:!?»)\]]+/.exec(seg.s);
      if(d){ despres = d[0]; seg.s = seg.s.slice(d[0].length); }
    }
    html += _formulaAHtml(t.s, abans, despres);
  }
  return html;
}

/* Demana per endavant les dues lletres que fan servir totes les fórmules.
   tasca.html ho crida quan la tasca té alguna errada: així, quan l'alumne
   obre un exercici, les fórmules surten de cop i no després d'un instant
   en blanc. Si el navegador no ho sap fer, no passa res. */
function preparaFormules(){
  try{
    if(document.fonts && document.fonts.load){
      document.fonts.load('1em KaTeX_Main');
      document.fonts.load('italic 1em KaTeX_Math');
    }
  }catch(e){}
}

/* ── Les targetes ─────────────────────────────────────────────────────── */

/* «f)» → «Apartat f)»,  «b) i c)» → «Apartats b) i c)»,
   «segon punt» → «Segon punt». */
function _llocAHtml(lloc){
  const l = String(lloc || '').trim();
  if(!l) return '';
  if(/^[a-z]\)/.test(l)){
    return (/^[a-z]\)\s+i\s+[a-z]\)/.test(l) ? 'Apartats ' : 'Apartat ') + texAHtml(l);
  }
  return texAHtml(l.charAt(0).toUpperCase() + l.slice(1));
}

function _filaErrada(classe, etiqueta, text){
  return '<div class="err-fila"><div class="err-et ' + classe + '">' + etiqueta + '</div>'
       + '<div class="err-val">' + texAHtml(text) + '</div></div>';
}

/* Una errada: on és i les dues files «On diu» i «Ha de dir» (i «Motiu», si
   l'interruptor és encès). Amb `senseEnunciat`, no s'hi escriu «Enunciat»
   perquè ja ho diu el títol del bloc. */
function _htmlErrada(e, senseEnunciat){
  let lloc = _llocAHtml(e.lloc);
  if(e.enunciat && !senseEnunciat) lloc = 'Enunciat' + (lloc ? ' · ' + lloc : '');
  let h = '<div class="err-card">';
  if(lloc) h += '<div class="err-lloc">' + lloc + '</div>';
  h += _filaErrada('err-et-on', 'On diu', e.ondiu);
  h += _filaErrada('err-et-ha', 'Ha de dir', e.hadedir);
  if(ERRADES_MOTIU && e.motiu) h += _filaErrada('err-et-mo', 'Motiu', e.motiu);
  return h + '</div>';
}

function _htmlObservacio(o){
  const lloc = _llocAHtml(o.lloc);
  return '<div class="err-card">'
       + (lloc ? '<div class="err-lloc">' + lloc + '</div>' : '')
       + '<div class="err-val">' + texAHtml(o.text) + '</div></div>';
}

function _quantes(n){
  return n === 1 ? 'una errada' : n + ' errades';
}

function _titolBloc(text){
  return '<div class="err-cap">' + _ICONA_AVIS + '<span>' + text + '</span></div>';
}

/* El bloc que surt dins de l'exercici, abans de la imatge: totes les errades
   i, si l'interruptor és encès, les observacions. Cadena buida si no hi ha res. */
function htmlErrades(u, n){
  const errs = erradesDe(u, n);
  const obs  = observacionsDe(u, n);
  let h = '';
  if(errs.length){
    const k = errs.filter(e => e.enunciat).length;      // quantes són a l'enunciat
    const titol = k === errs.length ? 'L’enunciat d’aquest exercici té ' + _quantes(k)
                : k === 0           ? 'El solucionari té ' + _quantes(errs.length) + ' en aquest exercici'
                :                     'Aquest exercici té ' + _quantes(errs.length);
    h += '<div class="err-panel" role="note">' + _titolBloc(titol)
       + errs.map(e => _htmlErrada(e, k === errs.length)).join('')
       + '</div>';
  }
  if(obs.length){
    const titol = obs.length === 1 ? 'Una observació sobre aquest exercici'
                                   : obs.length + ' observacions sobre aquest exercici';
    h += '<div class="err-panel err-obs" role="note">'
       + '<div class="err-cap"><span>' + titol + '</span></div>'
       + obs.map(_htmlObservacio).join('')
       + '</div>';
  }
  return h;
}

/* El bloc que surt a la llista de la tasca: només les errades d'enunciat,
   que l'alumne ha de conèixer abans de començar. Cadena buida si no n'hi ha. */
function htmlErradesEnunciat(u, n){
  const errs = erradesDe(u, n).filter(e => e.enunciat);
  if(!errs.length) return '';
  return '<div class="err-panel err-llista" role="note">'
       + _titolBloc(errs.length === 1 ? 'L’enunciat té una errada' : 'L’enunciat té ' + errs.length + ' errades')
       + errs.map(e => _htmlErrada(e, true)).join('')
       + '</div>';
}
